# Paquete de actualización para el fork de docs

Este ZIP contiene únicamente los dos archivos del modelo de datos modificados para reflejar las restricciones agregadas en T-18.

## Aplicación

Extrae el contenido de este ZIP en la raíz del fork `test-manager-library-3239188-docs`, aceptando reemplazar los dos archivos con las mismas rutas. Conserva el resto de carpetas y documentos del repositorio.

Archivos incluidos:
- `spec-python/data-model.md`
- `spec-.net/data-model.md`
